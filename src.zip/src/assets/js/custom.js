function slidetoggle(){
  alert("xcvxcv")
  JQuery()
  // var element = document.getElementsByTagName("body").classList.add("newClassName");

}
