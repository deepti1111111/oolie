import { Component, OnInit } from '@angular/core';
import { UrlSegment, Router } from '@angular/router';
import { Globals } from '../globals';

import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  public is_admin: boolean = false;
  public admin_info: any = {};
  public BASE_URL:string = "";
  constructor(private router: Router,public global: Globals, private http: HttpClient) {

    this.BASE_URL = this.global.APIURL;
  }

  ngOnInit(): void {

    this.sessionStatus();


  }

  sessionStatus() {
    let userdata = localStorage.getItem('user');
    console.log(userdata);
    if (userdata) {
      this.is_admin = true;
      this.admin_info = JSON.parse(userdata);
      console.log("user is logged IN");
      this.router.navigate(['dashboard']);
    } else {
      console.log("User is not logged IN ");
    }
  }


  public toggle:boolean = true;
  toggleNav(slidenav:boolean){
    this.toggle = !slidenav;
    console.log(this.toggle)

  }
  logout()
  {
    localStorage.removeItem('user');
    window.location.reload();
  }
}
