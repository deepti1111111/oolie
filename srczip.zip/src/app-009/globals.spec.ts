import { Globals } from './globals';

describe('Globals', () => {
  it('should create an instance', () => {
    expect(new Globals()).toBeTruthy();
  });
});
